﻿ <?php

/*
Leave a comment bot read the read me file for the Copyright
(Copyright Jacopo Chevalley de Rivaz 2017 LCommentBot)

Creato da @JackChevalley 
By @JackChevalley
05/09/2017
*/
{
$lang = "more/lingue/$lingua/";
$semid = "more/utenti/";
$dir = "more/utenti/$userID/";
$com = "more/utenti/$userID/commenti.txt";
$mes = "more/utenti/$userID/mex.txt";
$id = "more/utenti/$userID/id.txt";
$put = "more/utenti/$userID/put.txt";
$puta = "more/utenti/$userID/puta.txt";
$anon =  "more/utenti/$userID/anon.txt";
$tizio = "more/utenti/$userID/nome.txt";
$list = "more/utenti/$userID/list.txt";
$mlink = "more/utenti/$userID/link.txt";
$inlinen = "more/utenti/$userID/inline.txt";

$back[] = array(
array(
"text" => "Indietro⬅️",
"callback_data" => "/back"),
);
}

//START GENERALE COMANDO /START
if($msg == "/start")
{
if(!is_dir($dir)) //CONTROLLO SE ESISTE LA CARTELLA
{
$link = "t.me/LCommentBot?start=C$userID";
mkdir("more/utenti/$userID");
mkdir("more/utenti/$userID/commentlist");
file_put_contents($com,"");
file_put_contents($mes,"");
file_put_contents($id,"");
file_put_contents($puta,"");
file_put_contents($put,"");
file_put_contents($mlink,$link);
file_put_contents($anon,"~Anonimo");
file_put_contents($tizio,$nome);
file_put_contents($list,"<b>Verrà aggiunto un comando ogni volta che ti arriverà un nuovo commento</b>
Se qui sotto non ci sono comandi vuol dire che non hai commenti\n\n");
file_put_contents($inlinen,"Ei ragazzi che ne dite di dire cosa ne pensate di me anonimamente premendo qui sotto?🙄 
Ci mettete meno di un minuto!😁");
}

$menu[] = array(
array(
"text" => "Info&Help🌐",
"callback_data" => "/help"),
array(
"text" => "Link🌀",
"callback_data" => "/linkg"),
);
$menu[] = array(
array(
"text" => "Leggi commenti📋",
"callback_data" => "/lista"),
);
$menu[] = array(
array(
"text" => "Usami inline in una chat 👉🏻",
"switch_inline_query" => ""),
);

sm($chatID,"Benvenuto nel primo bot per lasciarsi pareri in modo completamente anonimo!
Prima di cominiare premi su Help⤵️
<code>Sviluppato da @JackChevalley</code>",$menu);

file_put_contents($mes,"");
file_put_contents($id,"");
file_put_contents($put,"");
file_put_contents($puta,"");
file_put_contents($ano,"~Anonimo");
file_put_contents($tizio,$nome);
}

//START PER MEZZO DI LINK CREAZIONE CARTELLE
if(strpos($msg,"/start")===0)
{
if(!is_dir($dir))
{
mkdir("more/utenti/$userID");
mkdir("more/utenti/$userID/commentlist");
file_put_contents($com,"");
file_put_contents($mes,"");
file_put_contents($id,"");
file_put_contents($puta,"");
file_put_contents($put,"");
file_put_contents($anon,"~Anonimo");
file_put_contents($tizio,$nome);
file_put_contents($list,"<b>Verrà aggiunto un comando ogni volta che ti arriverà un nuovo commento</b>
Se non ci sono comandi vuol dire che non hai commenti\n\n");
file_put_contents($inlinen,"Ei ragazzi che ne dite di dire cosa ne pensate di me anonimamente premendo qui sotto?🙄 
Ci mettete meno di un minuto!😁");
}
}

//START IN BACK COMANDO /BACK
if($msg == "/back")
{
$menu[] = array(
array(
"text" => "Info&Help🌐",
"callback_data" => "/help"),
array(
"text" => "Link🌀",
"callback_data" => "/linkg"),
);
$menu[] = array(
array(
"text" => "Leggi commenti📋",
"callback_data" => "/lista"),
);
$menu[] = array(
array(
"text" => "Usami inline in una chat 👉🏻",
"switch_inline_query" => ""),
);

cb_reply($cbid, "", true, $cbmid, "Benvenuto nel primo bot per lasciarsi pareri in modo completamente anonimo!
Prima di cominiare premi su Help⤵️
<code>Sviluppato da @JackChevalley</code>",$menu);	

file_put_contents($mes,"");
file_put_contents($id,"");
file_put_contents($put,"");
file_put_contents($puta,"");
file_put_contents($anon,"~Anonimo");
file_put_contents($tizio,$nome);
}

//COMANDO RESET
if($msg == "/aggiorna")
{
file_put_contents($com,"");
file_put_contents($mes,"");
file_put_contents($id,"");
file_put_contents($put,"");
file_put_contents($puta,"");
file_put_contents($anon,"~Anonimo");
file_put_contents($tizio,$nome);
file_put_contents($list,"<b>Verrà aggiunto un comando ogni volta che ti arriverà un nuovo commento</b>
Se non ci sono comandi qui sotto vuol dire che non hai commenti
");
sm($chatID,"Resettato con successo");
}

//RICEZIONE START PERSONALIZZATO
if(strpos($msg,"/start")===0)
{
	$arg = explode(" ",$msg);
	
	if(strpos($arg[1], "C")===0)
	{
		$utente = str_replace("C","",$arg[1]);						//ID UTENTE IN QUESTIONE
		$nom = file_get_contents("more/utenti/$utente/nome.txt");	//NOME DELL'UTENTE IN QUESTIONE
		file_put_contents($id,$utente);								//METTO ID UTENTE NEL FILE
		
		$menu[] = array(
		array(
		"text" => "Leggi commenti📋",
		"callback_data" => "/listau"),
		);
		$menu[] = array(
		array(
		"text" => "Lascia un commento📝",
		"callback_data" => "/commenta"),
		);
		
		sm($chatID,"Salve! Benvenuto nel catalogo di $nom",$menu);
	}
}

//COMMENTA UN UTENTE
if($msg == "/commenta")
{
	$id = file_get_contents($id);
	
	if($id == $userID)
	{
		cb_reply($cbid, "", true, $cbmid, "Beccatoo😜
Non puoi auto-commentarti dai",$back);
	}
	else
	{
		cb_reply($cbid, "", true, $cbmid, "Manda adesso il messaggio da lasciare🖊 \nIn seguito deciderai per Anonimo o meno \n/cancel per annullare");
		
		file_put_contents($anon,"~Anonimo");
		file_put_contents($mes,"A");
	}
}

//RICEZIONE COMMENTO
if($msg and !(strpos($msg,"/")===0))
{
	$a = file_get_contents($mes);
	if($a == "A")
	{
		if(!(stripos($msg,"t.me/")!== false) and !(stripos($msg,"telegram.me/")!== false))
		{
			$menu[] = array(
			array(
			"text" => "Anonimo❌",
			"callback_data" => "/anonino"),
			);
			$menu[] = array(
			array(
			"text" => "Invia♻️",
			"callback_data" => "/send"),
			);
			$menu[] = array(
			array(
			"text" => "Annulla💔",
			"callback_data" => "/stop"),
			);		
			
			$nom = file_get_contents($anon);
			$data = date("d/m/Y");
			$fin = "<b>$data</b>\n<i>$msg</i>\n\n";
			$mex = "<b>$data</b>\n<i>$msg</i>\n\n$nom";

			sm($chatID,"↘️Il tuo commento appare↙️");
			sm($chatID,"$mex",$menu);
			file_put_contents($put,$mex);
			file_put_contents($puta,$fin);
		}
		else
		{
			sm($chatID,"‼️<b>Lo spam non è concesso manda un nuovo messaggio!</b>‼️");
		}
	}
}

//SELEZIONA ANONIMO O MENO
if($msg == "/anonino")		//ANONIMO NO
{
	file_put_contents($anon,"~$nome");
	$get = file_get_contents($puta);
	$nom = file_get_contents($anon);
	$fin = "$get$nom";
	$fine = "$get";
	file_put_contents($put,$fin);
	file_put_contents($puta,$fine);
	
	
	$menu[] = array(
	array(
	"text" => "Anonimo✅",
	"callback_data" => "/anonisi"),
	);
	$menu[] = array(
	array(
	"text" => "Invia♻️",
	"callback_data" => "/send"),
	);	
	$menu[] = array(
	array(
	"text" => "Annulla💔",
	"callback_data" => "/stop"),
	);

	cb_reply($cbid, "", true, $cbmid, "$fin",$menu);
}

if($msg == "/anonisi")		//ANONIMO SI
{
	file_put_contents($anon,"~Anonimo");
	$get = file_get_contents($puta);
	$nom = file_get_contents($anon);
	$fin = "$get$nom";
	$fine = "$get";
	file_put_contents($put,$fin);
	file_put_contents($puta,$fine);
	
	
	$menu[] = array(
	array(
	"text" => "Anonimo❌",
	"callback_data" => "/anonino"),
	);
	$menu[] = array(
	array(
	"text" => "Invia♻️",
	"callback_data" => "/send"),
	);	
	$menu[] = array(
	array(
	"text" => "Annulla💔",
	"callback_data" => "/stop"),
	);

	cb_reply($cbid, "", true, $cbmid, "$fin",$menu);
}

//INVIO MESSAGGIO ALL'UTENTE
if($msg == "/send")
{
	$mex = file_get_contents($put);
	$id = file_get_contents($id);
	
	$fine = "$mex\n||\n";
	$dir = "$semid/$id/commenti.txt";
	
	//SCRIVO IL COMMENTO
	$scrivi = 	fopen($dir,"a+");
				fwrite($scrivi,$fine);
				fclose($scrivi);
				
	//AGGIORNO I COMANDI			
	$a = file_get_contents($dir);
	$b = explode("||\n",$a);
	$cont = count($b);
	$cont--;
	
	$lista = "/num_$cont\n";
	$dir = "$semid/$id/list.txt";
	$scrivi = 	fopen($dir,"a+");
				fwrite($scrivi,$lista);
				fclose($scrivi);
	
	cb_reply($cbid, "", true, $cbmid, "Commento aggiunto😄");
	sm($id,"$mex");
	
	//RESET DI ALCUNI FILE
	file_put_contents($puta,"");
	file_put_contents($put,"");
	file_put_contents($mes,"");	
	file_put_contents($id,$userID);	
}

//INVIO LISTA PERSONALE
if($msg == "/lista")
{
	$lista = file_get_contents($list);
	file_put_contents($id,$userID);
	sm($chatID,$lista);
}

//INVIO LISTA DI ALTRI
if($msg == "/listau")
{
	$id = file_get_contents($id);
	$dir = "more/utenti/$id/list.txt";
	$lista = file_get_contents($dir);
	sm($chatID,$lista);
}

//INVIO MESSAGGI CON I COMMENTI
if(strpos($msg,"/num")===0)
{
	$id = file_get_contents($id);
	$dir = "more/utenti/$id/commenti.txt";
	
	$tot = file_get_contents($dir);
	$mex = explode("||\n",$tot);	
	
	$res = explode("_",$msg);
	$num = $res[1]-1;
	
	sm($chatID,"$mex[$num]");
}

//GENERAZIONE LINK
if($msg == "/linkg")
{
$link = "t.me/LCommentBot?start=C$userID";
cb_reply($cbid, "", true, $cbmid, "<b>Il tuo link...</b>\n$link",$back);	
file_put_contents($mlink,$link);
}

//COMANDO HELP
if($msg == "/help")
{
cb_reply($cbid, "", true, $cbmid, '<b>Come funziona il bot?</b>
Molto semplice! Per mezzo di questo bot potrai lasciare commenti agli altri utenti iscritti in modo anonimo o firmandoti per nome.
Per lasciare un commento ad una persona ti basterà premere sul suo link personale (che ti deve fornire lui stesso) e seguire i passaggi nel bot.
Se invece vuoi farti commentare ti basterà premere sul pulsante "Link🌀" e mandare ai tuoi amici quel link oppure potreste usarlo inlune un una chat premendo su Usami inline.
A loro volta dovranno solamente premerci e seguire i passaggi.
Potrai lasciare un solo commento per ogni utente!

<b>Come vedo i commenti nei miei confronti</b>
Per vedere i commenti nei tuoi confronti ti baserà mandare il comando /lista.
Ti verrà mandata una lista di comandi dove ogni comando corrisponde ad un commento.
Manda uno dei comandi elencati e ti verrà scritto il commento ineerente.
Ogni volta che ti arriva una valutazione da un utente riceverai una notifica.

<b>Utilizzo Inline</b>
Il bot può essere usato e personalizzato inline.
Come fare? Niente di più semplice! Prima di tutto fate /inline per personalizzare il vostro messaggio o per reimpostare quello classico dopo di che fate /start e premete sul pulsante al fondo.

Canale updates @LComment
<b>NB chiunque può leggere i commenti di chiunque ma per farlo dovrete disporre del link(lo stesso per lasciare un parere)</b>
',$back);
}

//COMANDO SET INLINE
if($msg == "/inline")
{
$menu[] = array(
array(
"text" => "Imposta📲",
"callback_data" => "/setinline"),
array(
"text" => "Resetta♻️",
"callback_data" => "/resetinline"),
);	
$menu[] = array(
array(
"text" => "Vedi 👀",
"switch_inline_query_current_chat" => "Premi qui sopra"),
);
$menu[] = array(
array(
"text" => "Indietro⬅️",
"callback_data" => "/back"),
);

sm($chatID, "Da qui potrai cambiare il messaggio inline da mandare in gruppi/canali.
Premi su <i>Resetta</i> per reimpostare quello iniziale

Per vedere il tuo messaggio premi qui sotto",$menu);

}

//SETINLINE
if($msg == "/setinline")
{
	file_put_contents($mes,"Se");
	cb_reply($cbid, "", true, $cbmid, "Manda ora il messaggio che vorresti impostare come messaggio inline. Per cambiarlo ti basterà rifate /inline ☺️",$back);
}

//RESETINLINE
if($msg == "/resetinline")
{
	file_put_contents($inlinen,"Ei ragazzi che ne dite di dire cosa ne pensate di me anonimamente premendo qui sotto?🙄 
Ci mettete meno di un minuto!😁");
cb_reply($cbid, "", true, $cbmid, "Resettato con successo ♻️",$back);

}

//ANNULLA INVIO
if($msg == "/stop")
{
$menu[] = array(
array(
"text" => "Indietro⬅️",
"callback_data" => "/back"),
);
cb_reply($cbid, "", true, $cbmid, "Annullato con successo",$menu);
file_put_contents($puta,"");
file_put_contents($put,"");
file_put_contents($mes,"");	
file_put_contents($id,"");
}

//COMANDO STOP
if($msg == "/cancel")
{
$menu[] = array(
array(
"text" => "Indietro⬅️",
"callback_data" => "/back"),
);
sm($chatID,"Annullato con successo",$menu);
file_put_contents($puta,"");
file_put_contents($put,"");
file_put_contents($mes,"");	
file_put_contents($id,"");
}

//COMANDO FEEDBACK
if($msg == "/feedback")
{
sm($chatID,"Manda adesso il feedback da inoltrare allo staff del bot 😄 ",$back);

file_put_contents($mes,"Fd");
}

//INVIO MESSAGGI VARI
if($msg and !(strpos($msg,"/")===0))
{
$a = file_get_contents($mes);

if($a == "Fd")
{
$msgid = $update["message"]["message_id"];
$ja = 158472703;
fw($ja,$chatID,$msgid);
sm($chatID,"Mandato👍🏻
");
}
if($a == "Se")
{
file_put_contents($inlinen,$msg);
sm($chatID,"Impostato😁",$back);
}
file_put_contents($mes," ");
}

//MODALITA' INLINE
if($update["inline_query"])
{
//VAR INLINE	
$inline = $update["inline_query"]["id"];
$msg = $update["inline_query"]["query"];
$userID = $update["inline_query"]["from"]["id"];
$username = $update["inline_query"]["from"]["username"];
$name = $update["inline_query"]["from"]["first_name"];

$link = "t.me/LCommentBot?start=C$userID";

if(!is_dir("more/utenti/$userID"))
{
	$tit = "‼️AVVIAMI PRIMA️‼️";
	$dsc = "AVVIAMI IN PRIVATO PRIMA";
	$mex = "*Devo prima essere avviato in privato!*\nPremi qui sotto";
	$keyboard = array(
    "inline_keyboard" => array(array(array("text" => "Avviami ora👉🏻", "url" => "t.me/LCommentBot")))
);
}
else
{
if(file_exists("more/utenti/$userID/inline.txt"))
{
	$resul = file_get_contents("more/utenti/$userID/inline.txt");
	$mex = $resul;
	$dsc = "Premi qui per mandare un pulsante per farti lasciare un commento dagli altri utenti";
	$tit = "Fatti commentare❕";
	$keyboard = array(
		"inline_keyboard" => array(array(array("text" => "Commentami🗣", "url" => "$link")))
	);
}
else
{
	$mex = "Ei ragazzi che ne dite di dire cosa ne pensate di me anonimamente premendo qui sotto?🙄 
Ci mettete meno di un minuto!😁";
	$dsc = "Premi qui per mandare un pulsante per farti lasciare un commento dagli altri utenti";
	$tit = "Fatti commentare❕";
	$keyboard = array(
		"inline_keyboard" => array(array(array("text" => "Commentami🗣", "url" => "$link")))
	);
}
}

$json = array(
//prima riga risultati

array(
'type' => 'article',
'id' => 'kakfieokakfieofo',
'title' => "$tit",
'reply_markup' => $keyboard,
'description' => "$dsc",
'message_text' => "$mex",
'parse_mode' => 'Markdown',
),
);	


$json = json_encode($json);
$args = array(
'inline_query_id' => $inline,
'results' => $json,
'cache_time' => 5
);
$r = new HttpRequest("post", "https://api.telegram.org/$api/answerInlineQuery", $args);
}

if($msg == "/vedii")
{
	$inlinn = file_get_contents($inlinen);
		sm($chatID,"a $inlinn");
}
