<?php


//configurazioni
$config = array(

"formattazione_predefinita" => "HTML",
     //o "Markdown" o "" per nulla


"formattazione_messaggi_globali" => "HTML",



"nascondi_anteprima_link" => false,


"tastiera_predefinita" => "inline",
       //metti "normale" per mettere le tastiere vecchie


"funziona_nei_canali" => true,
"funziona_messaggi_modificati" => true,
"funziona_messaggi_modificati_canali" => true,


);


//non toccare
require 'functions.php';



//plugins

$plugins = array(

"inline.php" => false,
"gruppi.php" =>false,
"feedback.php" =>false,
"utenti.php" => true,

);




