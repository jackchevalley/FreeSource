This project is made my Jacopo Chevalley de Rivaz
On this source there is a GNU Licence so please read the file license.txt that you can find in the some directory of this one

You can use the source for every project that you want but you have to write (where who use the program can see it) that it is a copy/fork of the main project
Tks and good work
You can find the main program on t.me/lcommentbot 

Jacopo Chevalley de Riaz
Turin / Italy
10/12/2017
